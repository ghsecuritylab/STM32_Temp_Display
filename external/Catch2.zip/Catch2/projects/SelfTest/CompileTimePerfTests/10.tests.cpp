// Include set of usage tests multiple times - for compile-time performance testing
// (do not run)

#include "All.tests.cpp"
#include "All.tests.cpp"
#include "All.tests.cpp"
#include "All.tests.cpp"
#include "All.tests.cpp"
#include "All.tests.cpp"
#include "All.tests.cpp"
#include "All.tests.cpp"
#include "All.tests.cpp"
#include "All.tests.cpp"
