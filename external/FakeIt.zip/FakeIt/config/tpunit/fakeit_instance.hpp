#pragma once

#include "TpUnitFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::TpUnitFakeit::getInstance();
